 awk '{print $1,$2,$5, $6}' $1_Dealer_schedule.txt | grep -i $2 $1_Dealer_schedule.txt | awk '{print $1,$2,$5,$6}'



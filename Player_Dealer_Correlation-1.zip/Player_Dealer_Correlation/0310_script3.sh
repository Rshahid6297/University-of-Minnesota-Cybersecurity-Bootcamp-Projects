awk '{print $1,$2,$5, $6}' 0310_Dealer_schedule.txt | grep -i '02:00:00 PM' 0310_Dealer_schedule.txt | awk '{print $1,$2,$5,$6}'


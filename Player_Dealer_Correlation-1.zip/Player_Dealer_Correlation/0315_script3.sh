awk '{print $1,$2,$5, $6}' 0315_Dealer_schedule.txt | grep -i '02:00:00 PM' 0315_Dealer_schedule.txt | awk '{print $1,$2,$5,$6}'

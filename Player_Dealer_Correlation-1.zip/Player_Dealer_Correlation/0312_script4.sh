awk '{print $1,$2,$5, $6}' 0312_Dealer_schedule.txt | grep -i '08:00:00 PM' 0312_Dealer_schedule.txt | awk '{print $1,$2,$5,$6}'
